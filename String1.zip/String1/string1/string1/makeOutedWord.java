public String makeOutWord(String out, String word) {
    String begin = out.substring(0, 2);
    String end = out.substring(2);
    return begin + word + end;
}
