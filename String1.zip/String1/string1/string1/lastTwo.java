public String lastTwo(String str) {
    if (str.length() < 2) {
        return str;
    }
    String front = str.substring(0, str.length() - 2);
    String lastTwo = str.substring(str.length() - 2);
    String shifted = lastTwo.charAt(1) + "" + lastTwo.charAt(0);
    return front + shifted;
}
