public String right2(String str) {
    int len = str.length();
    String lastTwo = str.substring(len - 2, len);
    String firstPart = str.substring(0, len - 2);
    return lastTwo + firstPart;
}
