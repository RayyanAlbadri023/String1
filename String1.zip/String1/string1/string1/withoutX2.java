public String withoutX2(String str) {
    if (str.length() < 2) {
        return str.replace("x", "");
    }

    String a = "";
    String b = "";

    if (str.charAt(0) != 'x') {
        a = str.substring(0,1);
    }

    if (str.charAt(1) != 'x') {
        b = str.substring(1,2);
    }

    return a + b + str.substring(2);
}